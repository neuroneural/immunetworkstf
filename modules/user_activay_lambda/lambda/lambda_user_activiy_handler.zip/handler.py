import boto3
import json
import os
from datetime import datetime

# print(str(datetime.now()))
# target_date = datetime.strptime('2024-01-26 16:29:57.876750', '%Y-%m-%d %H:%M:%S.%f')
# print(target_date)
# print((datetime.now()-target_date).total_seconds() / 60)

def deactivate(userEmail,runid):
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': str(userEmail)}}
    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    
    if Items['Count']>0:
        for item in Items['Items']:
            if item['runid']['N'] == str(runid):
                user_runs_items = dynamodb.scan(TableName=os.environ['user_runs_table'])
                for user_run in user_runs_items['Items']:
                    if user_run['runid']['N'] == str(runid):
                        user_runs_item = user_run
                        
                
                active_user_items = dynamodb.scan(TableName=os.environ['active_users_table'])
                for active_user in active_user_items['Items']:
                    if active_user['runid']['N'] == str(runid):
                        active_users_item = active_user
                
                results_table_items = dynamodb.scan(TableName=os.environ['results_table'])
                for results_table in results_table_items['Items']:
                    if results_table['runid']['N'] == str(runid):
                        results = results_table['result']['S']
                        
                last_active_items = dynamodb.scan(TableName=os.environ['last_active_table'])
                for last_active_table in last_active_items['Items']:
                    if last_active_table['runid']['N'] == str(runid):
                        last_active_item = last_active_table
                
                weights_items = dynamodb.scan(TableName=os.environ['weights_table'])
                for weights_item in weights_items['Items']:
                    if weights_item['runid']['N'] == str(runid):
                        weight_item = weights_item
                
                if userEmail in weight_item:
                    weight_item.pop(userEmail)
                
                if userEmail in user_runs_item: 
                    user_runs_item.pop(userEmail)
                if userEmail in active_users_item['users']['SS']:
                    active_users_item['users']['SS'].pop(active_users_item['users']['SS'].index(userEmail))
                if len(active_users_item['users']['SS']) == 0:
                    active_users_item['users']['SS'].append('')
                if userEmail in last_active_item:    
                    last_active_item.pop(userEmail)
                
                
                
                dynamodb.put_item(TableName=os.environ['user_runs_table'], Item=user_runs_item)
                dynamodb.put_item(TableName=os.environ['active_users_table'], Item=active_users_item)
                dynamodb.put_item(TableName=os.environ['last_active_table'], Item=last_active_item)
                dynamodb.put_item(TableName=os.environ['weights_table'], Item=weights_item)
                
                return {'statusCode':200,'user_active':0,'body':'user is deactivated'}
                
    return {'statusCode':500,'user_active':1,'body':"user not registerd in the given computation"}

def activate(userEmail,runid):
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': str(userEmail)}}
    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    
    if Items['Count']>0:
        for item in Items['Items']:
            if item['runid']['N'] == str(runid):
                user_runs_items = dynamodb.scan(TableName=os.environ['user_runs_table'])
                active_user_items = dynamodb.scan(TableName=os.environ['active_users_table'])
                results_table_items = dynamodb.scan(TableName=os.environ['results_table'])
                last_active_items = dynamodb.scan(TableName=os.environ['last_active_table'])
                weights_items = dynamodb.scan(TableName=os.environ['weights_table'])
                
                for user_run in user_runs_items['Items']:
                    if user_run['runid']['N'] == str(runid):
                        user_runs_item = user_run
                
                for active_user in active_user_items['Items']:
                    if active_user['runid']['N'] == str(runid):
                        active_users_item = active_user
                        
                for results_table in results_table_items['Items']:
                    if results_table['runid']['N'] == str(runid):
                        results = results_table['result']['S']
                
                for last_active_table in last_active_items['Items']:
                    if last_active_table['runid']['N'] == str(runid):
                        last_active_item = last_active_table
                        
                for weights_item in weights_items['Items']:
                    if weights_item['runid']['N'] == str(runid):
                        weight_item = weights_item
                
                
                user_runs_item.update({userEmail:{'S':results}})
                weights_item.update({userEmail:{'S':results}})
                
                if '' in active_users_item['users']['SS']:
                    active_users_item['users']['SS'].pop(active_users_item['users']['SS'].index(''))
                active_users_item['users']['SS'].append(userEmail)
                active_users_item['users']['SS'] = list(set(active_users_item['users']['SS']))
                last_active_item.update({userEmail:{'S':str(datetime.now())}})
                dynamodb.put_item(TableName=os.environ['user_runs_table'], Item=user_runs_item)
                dynamodb.put_item(TableName=os.environ['active_users_table'], Item=active_users_item)
                dynamodb.put_item(TableName=os.environ['last_active_table'], Item=last_active_item)
                dynamodb.put_item(TableName=os.environ['weights_table'], Item=weights_item)
                
                
                return {'statusCode':200,'user_active':1,'body':'user activation completed'}
                
            
    return {'statusCode':500,'user_active':0,'body':"user not registerd in the given computation"}
    

def lambda_handler(event, context):
    print(event)
    if event['httpMethod'] == 'POST' and event['resourceName']=='/activate':
      if int(event['activation']) == 0:
        return deactivate(event['userEmail'],event['runid'])
      elif int(event['activation']) ==1:
        return activate(event['userEmail'],event['runid'])
         
    else:
        return {'statusCode':500,'body':'invalid input'}