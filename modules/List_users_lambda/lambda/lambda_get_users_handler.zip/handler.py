import os
import json
import boto3

def lambda_handler(event, context):
    print(event)
    if event['httpMethod']=='GET':
        client = boto3.client('cognito-idp', region_name = os.environ['region'])
        items = client.list_users(UserPoolId=os.environ['user_pool_id'],AttributesToGet=['email'])
        response = []
        for val in items['Users']:
            for obj in val['Attributes']:
                response.append(obj['Value'])
        return {'statusCode':200, 'body':response}
    else:
        return {'statusCode':500,'body':'Not valid input'} 