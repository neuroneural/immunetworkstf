import os
import json
import boto3
def lambda_handler(event, context):
  print(event)
  try:
    if event['resourceName'] == '/login' and event['httpMethod'] == 'POST':
      if event['REQUEST'] == 'REFRESH':
        
        client = boto3.client('cognito-idp', region_name=os.environ['region'])
        try:  
            auth_response = client.initiate_auth(
                AuthFlow='REFRESH_TOKEN',
                AuthParameters={'REFRESH_TOKEN':event['REFRESH_TOKEN']},
                ClientId=os.environ['cognito_user_pool_client_id']
                )
                
            return {'statusCode':200,'body':auth_response}
            
        except client.exceptions.NotAuthorizedException as e:
            return {'statusCode':404,'body':'NotAuthorizedException'}
            
        except Exception as e:
            return {'statusCode':500,'body':str(e)}
            
      elif event['REQUEST'] == 'LOGIN':
            client = boto3.client('cognito-idp', region_name=os.environ['region'])
            try:
                auth_response = client.initiate_auth(
                            AuthFlow        ='USER_PASSWORD_AUTH',
                            AuthParameters  ={'USERNAME': event['USERNAME'],'PASSWORD': event['PASSWORD']},
                            ClientId        = os.environ['cognito_user_pool_client_id']
                            )
                return {'statusCode':200,'body':auth_response}
                
            except client.exceptions.UserNotFoundException as e:
                return {'statusCode': 404,'body': 'UserNotFoundException'}
                
            except client.exceptions.UserNotConfirmedException as e:
                return {'statusCode': 404, 'body': 'UserNotConfirmedException'}
                
            except Exception as e:
                return {'statusCode': 500,'body': str(e)}
            
    elif event['resourceName'] == "/identityadd" and event['httpMethod'] == 'POST':
        try:
            client = boto3.client('ses',region_name = os.environ['region'])
            response = client.list_verified_email_addresses()
            if event['EMAIL'] in response['VerifiedEmailAddresses']:
                client = boto3.client('cognito-idp', region_name=os.environ['region'])
                try:
                    signup_response = client.sign_up(
                        ClientId=os.environ['cognito_user_pool_client_id'],
                        Username=event['USERNAME'],
                        Password=event['PASSWORD'],
                        UserAttributes=[
                            {
                                'Name': 'email',
                                'Value': event['EMAIL']
                                
                            },],)
                            
                    return {'statusCode':200,'body':signup_response}
                    
                except client.exceptions.UsernameExistsException as e:
                    return {'statusCode':404,'body': 'UsernameExistsException'}
                except Exception as e:
                    return {'statusCode':500,'body':str(e)}
            else:
                response = client.verify_email_identity(EmailAddress=event["EMAIL"])
                return {'statusCode':404,'body':'please verify SES email address to continue signup for email id '+event['EMAIL']}
        except Exception as e:
            return {'statusCode':500, 'body':str(e)}
    else:
      return {'statusCode':500,'body':'Not valid input'}
  except:
    return {'statusCode':500,'body':'Not valid input'}    