import os
import json
import boto3
from datetime import datetime


def upload(runid,userEmail, gradients):
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': str(userEmail)}}
    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    
    if Items['Count']>0:
        for item in Items['Items']:
            if item['runid']['N'] == str(runid):
                user_runs_items = dynamodb.scan(TableName=os.environ['user_runs_table'])
                for user_run in user_runs_items['Items']:
                    if user_run['runid']['N'] == str(runid):
                        user_runs_item = user_run
                
                active_user_items = dynamodb.scan(TableName=os.environ['active_users_table'])
                for active_user in active_user_items['Items']:
                    if active_user['runid']['N'] == str(runid):
                        active_users_item = active_user
                
                last_active_items = dynamodb.scan(TableName=os.environ['last_active_table'])
                for last_active_table in last_active_items['Items']:
                    if last_active_table['runid']['N'] == str(runid):
                        last_active_item = last_active_table
                
                if userEmail in active_users_item['users']['SS']:
                    user_runs_item.update({userEmail:{"S":str(gradients)}})
                    last_active_item.update({userEmail:{'S':str(datetime.now())}})
                    dynamodb.put_item(TableName=os.environ['user_runs_table'], Item=user_runs_item)
                    dynamodb.put_item(TableName=os.environ['last_active_table'], Item=last_active_item) 
                    return {'statusCode':200,'uploaded_results':1,"message":"uploaded the gradients"}
                else:
                    return {'statusCode':500,'uploaded_results':0,"message":" can not upload the gradients as user is inactive"}
                
    return {'statusCode':500,'uploaded_results':0,"message":"can not upload the gradients as user is not in the computation"}    
                    


def lambda_handler(event, context):
    # TODO implement
    print(event)
    if event['httpMethod'] == 'POST' and event['resourceName']=='/results':
        return upload(event['runid'],event['userEmail'],event['gradients'])
    else:
        return {'statusCode':500,'uploaded_results':0,"message":"Invalid Inpu"}
