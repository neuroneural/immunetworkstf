import json
import os
import ast
import boto3
import numpy as np
from datetime import datetime
dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])

def calculate_average(arrays_list):
    n = len(arrays_list)
    if n == 0:
        return None
    sum_arrays = [np.zeros_like(arr) for arr in arrays_list[0]]
    for arrays in arrays_list:
        for i, arr in enumerate(arrays):
            sum_arrays[i] += arr
    average_arrays = [sum_arr / n for sum_arr in sum_arrays]
    return average_arrays

def get_user_runs(runid):
    user_runs_items = dynamodb.scan(TableName=os.environ['user_runs_table'])
    for user_run in user_runs_items['Items']:
        if user_run['runid']['N'] == str(runid):
            return user_run
            
def get_active_users(runid):
    active_user_items = dynamodb.scan(TableName=os.environ['active_users_table'])
    for active_user in active_user_items['Items']:
        if active_user['runid']['N'] == str(runid):
            return active_user

def get_results(runid):
    results_items = dynamodb.scan(TableName=os.environ['results_table'])
    for results in results_items['Items']:
        if results['runid']['N'] == str(runid):
            return results

def get_last_activity(runid):
    last_active_items = dynamodb.scan(TableName=os.environ['last_active_table'])
    for last_active_table in last_active_items['Items']:
        if last_active_table['runid']['N'] == str(runid):
            return last_active_table
            
def get_runs(runid,userEmail):
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': str(userEmail)}}
    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    
    if Items['Count']>0:
        for item in Items['Items']:
            if item['runid']['N'] == str(runid):
                return item

def generate_aggr(user_runs,active_users,result):
    gradients = []
    for user in active_users['users']['SS']:
        if user_runs[user]['S']!='None':
            local_grad = [np.array(array) for array in ast.literal_eval(user_runs[user]['S'])]
            user_runs[user]['S']='None'
            gradients.append(local_grad)
    result['result']['S'] = str([array.tolist() for array in calculate_average(gradients)])
    result['users']['SS'] = active_users['users']['SS']
    
    dynamodb.put_item(TableName=os.environ['user_runs_table'], Item=user_runs)
    dynamodb.put_item(TableName=os.environ['results_table'], Item=result)
    
    


def aggregate_gradient(runid,userEmail):
    runs =  get_runs(runid,userEmail)
    if runs:
        result = get_results(runid)
        if result['result']['S']=='None':
            active_users = get_active_users(runid)
            user_runs = get_user_runs(runid)
            last_active = get_last_activity(runid)
            for user in active_users['users']['SS']:
                if user_runs[user]['S']=='None':
                    if (datetime.now()-datetime.strptime(last_active[user]['S'], '%Y-%m-%d %H:%M:%S.%f')).total_seconds() / 60<int(runs['check_Threshold']['N']):
                        return {'statusCode':500,'result':'None','error':'Waiting for result'}
            
            generate_aggr(user_runs,active_users,result)
            result = get_results(runid)
            result['users']['SS'].remove(userEmail)
            output = {'statusCode':200,'result':result['result']['S'],'message':'Returned aggregated gradients'}
            if len(result['users']['SS'])==0:
                result['users']['SS']=['']
                result['result']['S']='None'
            dynamodb.put_item(TableName=os.environ['results_table'], Item=result)
            return output
        else:
            if userEmail in result['users']['SS']:
                result['users']['SS'].remove(userEmail)
                output = {'statusCode':200,'result':result['result']['S'],'message':'Returned aggregated gradients'}
                if len(result['users']['SS'])==0:
                    result['users']['SS']=['']
                    result['result']['S']='None'
                dynamodb.put_item(TableName=os.environ['results_table'], Item=result)
                return output
            else:
                last_active = get_last_activity(runid)
                if (datetime.now()-datetime.strptime(last_active[userEmail]['S'], '%Y-%m-%d %H:%M:%S.%f')).total_seconds() / 60<int(runs['check_Threshold']['N']):
                    return {'statusCode':500,'result':'None','error':'No result'}
            
            #convert results to 'None', users to [''] in results table
            result['result']['S'] = 'None'
            result['users']['SS'] = ['']
            dynamodb.put_item(TableName=os.environ['results_table'], Item=result)
            return {'statusCode':500,'result':'None','error':'No result'}
    else:
        return {'statusCode':500, 'error':'No run exists with specified ID'}
    
def lambda_handler(event, context):
    if event['httpMethod'] == 'POST' and event['resourceName']=='/agggrad':
        return aggregate_gradient(event['runid'],event['userEmail'])
    