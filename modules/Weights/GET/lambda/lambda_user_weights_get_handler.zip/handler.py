import json
import os
import ast
import boto3
# import numpy as np
from datetime import datetime
dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])


def get_user_weights(runid):
    user_runs_items = dynamodb.scan(TableName=os.environ['weights_table'])
    for user_run in user_runs_items['Items']:
        if user_run['runid']['N'] == str(runid):
            return user_run

def get_active_users(runid):
    active_user_items = dynamodb.scan(TableName=os.environ['active_users_table'])
    for active_user in active_user_items['Items']:
        if active_user['runid']['N'] == str(runid):
            return active_user
            
def get_last_activity(runid):
    last_active_items = dynamodb.scan(TableName=os.environ['last_active_table'])
    for last_active_table in last_active_items['Items']:
        if last_active_table['runid']['N'] == str(runid):
            return last_active_table

def calculate_average(arrays_list):
    return sum(arrays_list)/len(arrays_list)


def generate_aggr(weights,active_users):
    weights_list = []
    for user in active_users['users']['SS']:
        if weights[user]['S']!='None':
            weight = int(weights[user]['S'])
            weights_list.append(weight)
    if len(weights_list)>0:
        return calculate_average(weights_list)
    else:
        return 0
    
def get_runs(runid,userEmail):
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': str(userEmail)}}
    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    
    if Items['Count']>0:
        for item in Items['Items']:
            if item['runid']['N'] == str(runid):
                return item
            
def aggregate_weights(runid,userEmail):
            active_users = get_active_users(runid)
            runs =  get_runs(runid,userEmail)
            
            user_weights = get_user_weights(runid)
            last_active = get_last_activity(runid)
            for user in active_users['users']['SS']:
                if user_weights[user]['S']=='None':
                    if (datetime.now()-datetime.strptime(last_active[userEmail]['S'], '%Y-%m-%d %H:%M:%S.%f')).total_seconds() / 60<int(runs['check_Threshold']['N']):
                        return {'statusCode':500,'result':'None','error':'Waiting for Weights from all users'}
            
            
            return {'statusCode':200,'result':generate_aggr(user_weights,active_users)}
            
def lambda_handler(event, context):
    if event['httpMethod'] == 'GET' and event['resourceName']=='/weights':
        return aggregate_weights(event['runid'],event['userEmail'])
    