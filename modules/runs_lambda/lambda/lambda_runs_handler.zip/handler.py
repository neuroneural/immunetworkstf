import os
import boto3
import json


def scan_table_for_value_in_list( ):
    dynamodb = boto3.resource('dynamodb', region_name=os.environ['region'])
    table = dynamodb.Table(os.environ['runs_table'])
    response = table.scan()
    items = response.get('Items', [])
    response = {}
    for item in items:
        response.update({int(item['runid']):{
            'description':item['description'],
            'name':item['name'],
            'users':list(item['users']),
            'classes' : int(item['classes']['N'])
            }
        })
    return response


def scan_table_for_users_in_list( desired_value):
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': desired_value}}

    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    response = {}
    for item in Items['Items']:
        response.update({int(item['runid']['N']):{
            'description':item['description']['S'],
            'name':item['name']['S'],
            'users':list(item['users']['SS']),
            'classes' : int(item['classes']['N'])
            }
        })
    return response

def create_runs(Name,Description, Users, check_Threshold, classes):
    
    dynamodb = boto3.resource('dynamodb', region_name=os.environ['region'])
    table = dynamodb.Table(os.environ['runs_table'])
    response = table.scan()
    items = response.get('Items', [])
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    temp = {'users':{'SS':Users},'name':{'S':Name},'check_Threshold':{'N':str(check_Threshold)},'classes':{'N':str(classes)},'description':{'S':Description},'runid':{'N':str(len(items)+1)}}
    dynamodb.put_item(TableName=os.environ['runs_table'], Item=temp)
    dynamodb.put_item(TableName=os.environ['user_runs_table'], Item={'runid':{'N':str(len(items)+1)}})
    dynamodb.put_item(TableName=os.environ['weights_table'], Item={'runid':{'N':str(len(items)+1)}})
    dynamodb.put_item(TableName=os.environ['active_users_table'], Item={'runid':{'N':str(len(items)+1)},'users':{'SS':['']}})
    dynamodb.put_item(TableName=os.environ['results_table'], Item={'runid':{'N':str(len(items)+1)},'result':{'S':'None'},'users':{'SS':['']}})
    dynamodb.put_item(TableName=os.environ['last_active_table'], Item={'runid':{'N':str(len(items)+1)}})
    return 'Runs computation setup completed'

def lambda_handler(event, context):
    print(event)
    print(event['httpMethod'],event['resourceName'])
    if event['httpMethod'] == 'GET' and event['resourceName']=='/runs':
        return {'statusCode':200,'body':scan_table_for_value_in_list()}
    elif event['httpMethod'] == 'POST' and event['resourceName']=='/runs':
        return {'statusCode':200,'body':scan_table_for_users_in_list(event['userEmail'])}
    elif event['httpMethod'] == 'POST' and event['resourceName']=='/runs_update':
        return {'statusCode':200, 'body':create_runs(event['Name'],event['Description'], event['Users'], event['check_Threshold'], event['Classes'])}
    else:
        return {'statusCode':500,'body':'Not valid input'} 

