import os
import boto3
import json


def scan_table_for_value_in_list( ):
    dynamodb = boto3.resource('dynamodb', region_name=os.environ['region'])
    table = dynamodb.Table(os.environ['runs_table'])
    response = table.scan()
    items = response.get('Items', [])
    response = {}
    for item in items:
        response.update({int(item['runid']):{
            'description':item['description'],
            'name':item['name'],
            'users':list(item['users'])
            }
        })
    return response

def lambda_handler(event, context):
    print(event)
    if event['httpMethod'] == 'GET':
        return {'body':scan_table_for_value_in_list()}