import os
import boto3
import json


def scan_table_for_value_in_list( ):
    dynamodb = boto3.resource('dynamodb', region_name=os.environ['region'])
    table = dynamodb.Table(os.environ['runs_table'])
    response = table.scan()
    items = response.get('Items', [])
    response = {}
    for item in items:
        response.update({int(item['runid']):{
            'description':item['description'],
            'name':item['name'],
            'users':list(item['users'])
            }
        })
    return response


def scan_table_for_users_in_list( desired_value):
    dynamodb = boto3.client('dynamodb', region_name=os.environ['region'])
    filter_expression = f'contains(#col, :val)'
    expression_attribute_names = {'#col': 'users'}
    expression_attribute_values = {':val': {'S': desired_value}}

    Items = dynamodb.scan(
        TableName=os.environ['runs_table'],
        FilterExpression=filter_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values
    )
    response = {}
    for item in Items['Items']:
        response.update({int(item['runid']['N']):{
            'description':item['description']['S'],
            'name':item['name']['S'],
            'users':list(item['users']['SS'])
            }
        })
    return response

def lambda_handler(event, context):
    print(event)
    if event['httpMethod'] == 'GET':
        return {'body':scan_table_for_value_in_list()}
    elif event['httpMethod'] == 'POST':
        return {'body':scan_table_for_users_in_list(event['userEmail'])}
    else:
        return {'statusCode':500,'body':'Not valid input'} 